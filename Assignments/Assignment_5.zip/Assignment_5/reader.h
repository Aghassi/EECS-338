#include "common.h"
#ifndef SEMAPHORE_READER
#define SEMAPHORE_READER
void *reader(void *shared_data);
#endif
