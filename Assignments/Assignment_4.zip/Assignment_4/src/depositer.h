#include "common.h"
#ifndef SEMAPHORE_DEPOSITER
#define SEMAPHORE_DEPOSITER
void depositer(struct shared_data_info shared, int deposit);
#endif
