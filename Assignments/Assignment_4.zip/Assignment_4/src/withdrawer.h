#include "common.h"
#ifndef SEMAPHORE_CONSUMER
#define SEMAPHORE_CONSUMER
void withdrawer(struct shared_data_info shared, int amount);
#endif